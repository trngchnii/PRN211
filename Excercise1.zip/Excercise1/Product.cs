﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excercise1
{
    internal class Product
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public double Discount { get; set; }
        public Product(string name, double price, double discount) 
        {
            Name = name;
            Price = price;
            Discount = discount;
        }

        public double getImportTax()
        {
            return 0.10 * Price;
        }

        public void Display()
        {
            Console.WriteLine("Product Information:");
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Price: ${Price:F2}");
            Console.WriteLine($"Discount: {Discount}%");
            Console.WriteLine($"Import Tax: ${getImportTax():F2}");
        }

        public static Product Input()
        {
            Console.Write("Enter product name: ");
            string name = Console.ReadLine();

            Console.Write("Enter product price: ");
            double price = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter discount percentage: ");
            double discount = Convert.ToDouble(Console.ReadLine());

            return new Product(name, price, discount);
        }

        static void Main(string[] args)
        {

            Product pd1 = Product.Input();
            Product pd2 = Product.Input();
            
            Console.WriteLine("\nProduct 1 Information:");
            pd1.Display();
            
            Console.WriteLine("\nProduct 2 Information:");
            pd2.Display();

        }
    }
}
