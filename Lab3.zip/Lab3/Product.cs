﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    using System;
    using System.Collections;

    public class Product
    {
        public string Name { get; set; }
        public double Cost { get; set; }
        public int Quantity { get; set; }

        public override string ToString()
        {
            return $"Name: {Name}, Cost: {Cost}, Quantity: {Quantity}";
        }
    }

    class Program1
    {
        static void Main()
        {
            ArrayList productList = new ArrayList();

            productList.Add(new Product { Name = "Product1", Cost = 10.99, Quantity = 5 });
            productList.Add(new Product { Name = "Product2", Cost = 15.49, Quantity = 3 });
            productList.Add(new Product { Name = "Product3", Cost = 5.99, Quantity = 10 });
            productList.Add(new Product { Name = "Product4", Cost = 7.79, Quantity = 8 });
            productList.Add(new Product { Name = "Product5", Cost = 3.99, Quantity = 12 });

            foreach (Product product in productList)
            {
                Console.WriteLine(product.ToString());
            }
        }
    }



}
